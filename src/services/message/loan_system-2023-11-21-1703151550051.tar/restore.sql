--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Debian 16.1-1.pgdg120+1)
-- Dumped by pg_dump version 16.1 (Debian 16.1-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "LOAN_SYSTEM";
--
-- Name: LOAN_SYSTEM; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "LOAN_SYSTEM" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "LOAN_SYSTEM" OWNER TO postgres;

\connect "LOAN_SYSTEM"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Borrower; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Borrower" (
    id integer NOT NULL,
    full_name text NOT NULL,
    job_title text NOT NULL,
    address text NOT NULL,
    phone_number text NOT NULL,
    income money NOT NULL,
    outcome money NOT NULL,
    "CCCD" text NOT NULL
);


ALTER TABLE public."Borrower" OWNER TO postgres;

--
-- Name: Borrower_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Borrower_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Borrower_id_seq" OWNER TO postgres;

--
-- Name: Borrower_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Borrower_id_seq" OWNED BY public."Borrower".id;


--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    date_of_birth timestamp(3) without time zone NOT NULL,
    address text NOT NULL,
    phone_number text NOT NULL,
    email text,
    job_title text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    salary integer NOT NULL,
    profile_picture text,
    gender text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: Employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Employee_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Employee_id_seq" OWNER TO postgres;

--
-- Name: Employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Employee_id_seq" OWNED BY public."Employee".id;


--
-- Name: Lender; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Lender" (
    id integer NOT NULL,
    bank text NOT NULL,
    branch text NOT NULL,
    address text NOT NULL,
    full_name text NOT NULL,
    job_title text NOT NULL
);


ALTER TABLE public."Lender" OWNER TO postgres;

--
-- Name: Lender_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Lender_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Lender_id_seq" OWNER TO postgres;

--
-- Name: Lender_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Lender_id_seq" OWNED BY public."Lender".id;


--
-- Name: LoanContract; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoanContract" (
    id integer NOT NULL,
    money money NOT NULL,
    purpose text NOT NULL,
    loan_date timestamp(3) without time zone NOT NULL,
    expire_date timestamp(3) without time zone NOT NULL,
    contract_status text NOT NULL,
    loan_method text NOT NULL,
    "borrowerId" integer,
    "employeeId" integer,
    "lenderId" integer,
    "loanPackageId" integer
);


ALTER TABLE public."LoanContract" OWNER TO postgres;

--
-- Name: LoanContract_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LoanContract_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LoanContract_id_seq" OWNER TO postgres;

--
-- Name: LoanContract_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LoanContract_id_seq" OWNED BY public."LoanContract".id;


--
-- Name: LoanPackage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoanPackage" (
    id integer NOT NULL,
    name text NOT NULL,
    guarantee_type text NOT NULL,
    interest_rate numeric(65,30) NOT NULL,
    duration integer NOT NULL,
    description text NOT NULL,
    max_money money NOT NULL,
    min_money money NOT NULL,
    interest_period integer NOT NULL
);


ALTER TABLE public."LoanPackage" OWNER TO postgres;

--
-- Name: LoanPackage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LoanPackage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LoanPackage_id_seq" OWNER TO postgres;

--
-- Name: LoanPackage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LoanPackage_id_seq" OWNED BY public."LoanPackage".id;


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payment" (
    id integer NOT NULL,
    pay_date money NOT NULL,
    money money NOT NULL,
    principal_amount money NOT NULL,
    profit_amount money NOT NULL,
    payment_method text NOT NULL,
    financial_situation text NOT NULL,
    property_status text NOT NULL,
    "borrowerId" integer,
    "loanContractId" integer
);


ALTER TABLE public."Payment" OWNER TO postgres;

--
-- Name: Payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Payment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Payment_id_seq" OWNER TO postgres;

--
-- Name: Payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Payment_id_seq" OWNED BY public."Payment".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Borrower id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Borrower" ALTER COLUMN id SET DEFAULT nextval('public."Borrower_id_seq"'::regclass);


--
-- Name: Employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee" ALTER COLUMN id SET DEFAULT nextval('public."Employee_id_seq"'::regclass);


--
-- Name: Lender id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lender" ALTER COLUMN id SET DEFAULT nextval('public."Lender_id_seq"'::regclass);


--
-- Name: LoanContract id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanContract" ALTER COLUMN id SET DEFAULT nextval('public."LoanContract_id_seq"'::regclass);


--
-- Name: LoanPackage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanPackage" ALTER COLUMN id SET DEFAULT nextval('public."LoanPackage_id_seq"'::regclass);


--
-- Name: Payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment" ALTER COLUMN id SET DEFAULT nextval('public."Payment_id_seq"'::regclass);


--
-- Data for Name: Borrower; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Borrower" (id, full_name, job_title, address, phone_number, income, outcome, "CCCD") FROM stdin;
\.
COPY public."Borrower" (id, full_name, job_title, address, phone_number, income, outcome, "CCCD") FROM '$$PATH$$/3407.dat';

--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee" (id, full_name, date_of_birth, address, phone_number, email, job_title, start_date, salary, profile_picture, gender, password) FROM stdin;
\.
COPY public."Employee" (id, full_name, date_of_birth, address, phone_number, email, job_title, start_date, salary, profile_picture, gender, password) FROM '$$PATH$$/3405.dat';

--
-- Data for Name: Lender; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Lender" (id, bank, branch, address, full_name, job_title) FROM stdin;
\.
COPY public."Lender" (id, bank, branch, address, full_name, job_title) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: LoanContract; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoanContract" (id, money, purpose, loan_date, expire_date, contract_status, loan_method, "borrowerId", "employeeId", "lenderId", "loanPackageId") FROM stdin;
\.
COPY public."LoanContract" (id, money, purpose, loan_date, expire_date, contract_status, loan_method, "borrowerId", "employeeId", "lenderId", "loanPackageId") FROM '$$PATH$$/3413.dat';

--
-- Data for Name: LoanPackage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoanPackage" (id, name, guarantee_type, interest_rate, duration, description, max_money, min_money, interest_period) FROM stdin;
\.
COPY public."LoanPackage" (id, name, guarantee_type, interest_rate, duration, description, max_money, min_money, interest_period) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payment" (id, pay_date, money, principal_amount, profit_amount, payment_method, financial_situation, property_status, "borrowerId", "loanContractId") FROM stdin;
\.
COPY public."Payment" (id, pay_date, money, principal_amount, profit_amount, payment_method, financial_situation, property_status, "borrowerId", "loanContractId") FROM '$$PATH$$/3415.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3403.dat';

--
-- Name: Borrower_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Borrower_id_seq"', 1, false);


--
-- Name: Employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Employee_id_seq"', 1, false);


--
-- Name: Lender_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Lender_id_seq"', 1, false);


--
-- Name: LoanContract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LoanContract_id_seq"', 1, false);


--
-- Name: LoanPackage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LoanPackage_id_seq"', 1, false);


--
-- Name: Payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Payment_id_seq"', 1, false);


--
-- Name: Borrower Borrower_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Borrower"
    ADD CONSTRAINT "Borrower_pkey" PRIMARY KEY (id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (id);


--
-- Name: Lender Lender_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lender"
    ADD CONSTRAINT "Lender_pkey" PRIMARY KEY (id);


--
-- Name: LoanContract LoanContract_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanContract"
    ADD CONSTRAINT "LoanContract_pkey" PRIMARY KEY (id);


--
-- Name: LoanPackage LoanPackage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanPackage"
    ADD CONSTRAINT "LoanPackage_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: LoanContract LoanContract_borrowerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanContract"
    ADD CONSTRAINT "LoanContract_borrowerId_fkey" FOREIGN KEY ("borrowerId") REFERENCES public."Borrower"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LoanContract LoanContract_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanContract"
    ADD CONSTRAINT "LoanContract_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LoanContract LoanContract_lenderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanContract"
    ADD CONSTRAINT "LoanContract_lenderId_fkey" FOREIGN KEY ("lenderId") REFERENCES public."Lender"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LoanContract LoanContract_loanPackageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoanContract"
    ADD CONSTRAINT "LoanContract_loanPackageId_fkey" FOREIGN KEY ("loanPackageId") REFERENCES public."LoanPackage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_borrowerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_borrowerId_fkey" FOREIGN KEY ("borrowerId") REFERENCES public."Borrower"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_loanContractId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_loanContractId_fkey" FOREIGN KEY ("loanContractId") REFERENCES public."LoanContract"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

